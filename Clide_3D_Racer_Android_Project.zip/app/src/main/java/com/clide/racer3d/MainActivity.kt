package com.clide.racer3d

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.opengl.GLSurfaceView
import android.content.pm.ActivityInfo

class MainActivity : Activity() {
    private lateinit var game: RacerGLView
    private lateinit var coinsLabel: TextView
    private lateinit var statusLabel: TextView
    private lateinit var driveButton: Button
    private lateinit var garageButton: Button
    private var inGarage = false
    private var coins = 0
    private var selectedCar = 0
    private val carNames = arrayOf("STARTER GT", "NEON SPORT", "SUNSET TURBO", "MIDNIGHT X")
    private val carPrices = intArrayOf(0, 100, 250, 500)
    private val owned = mutableSetOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        window.navigationBarColor = Color.rgb(8, 15, 28)
        val prefs = getSharedPreferences("clide_racer", MODE_PRIVATE)
        coins = prefs.getInt("coins", 0)
        selectedCar = prefs.getInt("selected", 0)
        owned.addAll(prefs.getStringSet("owned", setOf("0"))!!.mapNotNull { it.toIntOrNull() })
        if (owned.isEmpty()) owned.add(0)
        if (selectedCar !in owned) selectedCar = 0

        game = RacerGLView(this)
        game.onCoinsEarned = { gained ->
            runOnUiThread {
                coins += gained
                getSharedPreferences("clide_racer", MODE_PRIVATE).edit().putInt("coins", coins).apply()
                refreshLabels()
            }
        }
        val root = FrameLayout(this)
        root.addView(game, FrameLayout.LayoutParams(-1, -1))

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(18, 10, 18, 8)
            setBackgroundColor(Color.argb(150, 5, 12, 24))
        }
        val owner = label("OWNER: CLIDE TABASON", 16, Color.WHITE)
        top.addView(owner, LinearLayout.LayoutParams(0, -2, 1f))
        coinsLabel = label("COINS: $coins", 16, Color.rgb(255, 220, 70))
        top.addView(coinsLabel)
        val topParams = FrameLayout.LayoutParams(-1, -2, Gravity.TOP)
        root.addView(top, topParams)

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(12, 8, 12, 14)
            setBackgroundColor(Color.argb(135, 5, 12, 24))
        }
        val left = button("◀ LEFT") { game.steer(-1) }
        val right = button("RIGHT ▶") { game.steer(1) }
        garageButton = button("GARAGE / BUY CAR") {
            if (inGarage) {
                selectedCar = (selectedCar + 1) % carNames.size
                game.setCar(selectedCar)
                refreshLabels()
            } else openGarage()
        }
        driveButton = button("START RACE") { startRace() }
        bottom.addView(left, LinearLayout.LayoutParams(0, 58, 1f).apply { setMargins(5,0,5,0) })
        bottom.addView(right, LinearLayout.LayoutParams(0, 58, 1f).apply { setMargins(5,0,5,0) })
        bottom.addView(garageButton, LinearLayout.LayoutParams(0, 58, 1.3f).apply { setMargins(5,0,5,0) })
        bottom.addView(driveButton, LinearLayout.LayoutParams(0, 58, 1.1f).apply { setMargins(5,0,5,0) })
        root.addView(bottom, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))

        statusLabel = label("3D HIGHWAY • DODGE TRAFFIC • COLLECT COINS", 15, Color.WHITE).apply {
            setBackgroundColor(Color.argb(120, 5, 12, 24))
            setPadding(12, 8, 12, 8)
        }
        root.addView(statusLabel, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = 58
        })

        setContentView(root)
        refreshLabels()
    }

    private fun label(text: String, size: Int, color: Int) = TextView(this).apply {
        this.text = text
        textSize = size.toFloat()
        setTextColor(color)
        typeface = android.graphics.Typeface.create("sans-serif-condensed", android.graphics.Typeface.BOLD)
    }

    private fun button(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text
        textSize = 12f
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(24, 103, 174))
        setOnClickListener { action() }
    }

    private fun refreshLabels() {
        coinsLabel.text = "COINS: $coins"
        val price = carPrices[selectedCar]
        statusLabel.text = if (inGarage) {
            if (selectedCar in owned) "GARAGE: ${carNames[selectedCar]} • OWNED • TAP BUY/SELECT"
            else "LOCKED: ${carNames[selectedCar]} • PRICE: $price COINS"
        } else "3D HIGHWAY • DODGE TRAFFIC • COLLECT COINS"
        garageButton.text = if (inGarage) "NEXT CAR" else "GARAGE / BUY CAR"
        driveButton.text = if (inGarage) {
            if (selectedCar in owned) "SELECT CAR" else "BUY CAR"
        } else "START RACE"
    }

    private fun openGarage() {
        inGarage = !inGarage
        if (inGarage) game.showGarage(true) else game.showGarage(false)
        refreshLabels()
    }

    private fun startRace() {
        if (inGarage) {
            val price = carPrices[selectedCar]
            if (selectedCar in owned) {
                getSharedPreferences("clide_racer", MODE_PRIVATE).edit().putInt("selected", selectedCar).apply()
                game.setCar(selectedCar)
                inGarage = false
                game.showGarage(false)
                statusLabel.text = "SELECTED: ${carNames[selectedCar]}"
            } else if (coins >= price) {
                coins -= price
                owned.add(selectedCar)
                getSharedPreferences("clide_racer", MODE_PRIVATE).edit()
                    .putInt("coins", coins).putStringSet("owned", owned.map { it.toString() }.toSet()).apply()
                statusLabel.text = "PURCHASED ${carNames[selectedCar]}!"
                refreshLabels()
            } else {
                statusLabel.text = "NOT ENOUGH COINS — PLAY A RACE FIRST"
            }
        } else {
            game.startRace()
            statusLabel.text = "RACE ON! STEER LEFT OR RIGHT"
        }
        refreshLabels()
    }

    override fun onPause() { super.onPause(); game.onPause() }
    override fun onResume() { super.onResume(); game.onResume() }
}
