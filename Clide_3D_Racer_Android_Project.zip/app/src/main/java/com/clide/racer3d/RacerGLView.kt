package com.clide.racer3d

import android.content.Context
import android.opengl.GLSurfaceView
import android.opengl.GLES20
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.random.Random

class RacerGLView(context: Context) : GLSurfaceView(context) {
    private val rendererGame = RacerRenderer()
    var onCoinsEarned: ((Int) -> Unit)? = null
        set(value) { field = value; rendererGame.onCoinsEarned = value }
    init {
        setEGLContextClientVersion(2)
        setRenderer(rendererGame)
        renderMode = RENDERMODE_CONTINUOUSLY
    }
    fun steer(dir: Int) = rendererGame.steer(dir)
    fun startRace() = rendererGame.startRace()
    fun showGarage(show: Boolean) = rendererGame.showGarage(show)
    fun setCar(index: Int) = rendererGame.setCar(index)
}

private data class Rival(var lane: Int, var z: Float, var color: FloatArray)
private data class Pickup(var lane: Int, var z: Float)

class RacerRenderer : GLSurfaceView.Renderer {
    @Volatile private var lane = 1
    @Volatile private var running = false
    @Volatile private var garage = false
    @Volatile private var carType = 0
    private var score = 0
    private var spawn = 0
    private var coinSpawn = 0
    private var roadOffset = 0f
    private var speed = 0.12f
    private var last = System.nanoTime()
    private val rivals = mutableListOf<Rival>()
    private val pickups = mutableListOf<Pickup>()
    private var program = 0
    private var aPos = 0
    private var uMvp = 0
    private var uColor = 0
    private val projection = FloatArray(16)
    private val view = FloatArray(16)
    private val model = FloatArray(16)
    private val mvp = FloatArray(16)
    @Volatile var onCoinsEarned: ((Int) -> Unit)? = null
    private val colors = arrayOf(
        floatArrayOf(0.12f,0.45f,0.95f,1f),
        floatArrayOf(0.05f,0.9f,0.9f,1f),
        floatArrayOf(1f,0.42f,0.08f,1f),
        floatArrayOf(0.35f,0.18f,0.75f,1f)
    )
    private val vertexShader = """
        uniform mat4 uMVP;
        attribute vec3 aPosition;
        void main(){ gl_Position = uMVP * vec4(aPosition,1.0); }
    """.trimIndent()
    private val fragmentShader = """
        precision mediump float;
        uniform vec4 uColor;
        void main(){ gl_FragColor = uColor; }
    """.trimIndent()

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.40f, 0.70f, 0.88f, 1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        val vs = compile(GLES20.GL_VERTEX_SHADER, vertexShader)
        val fs = compile(GLES20.GL_FRAGMENT_SHADER, fragmentShader)
        program = GLES20.glCreateProgram()
        GLES20.glAttachShader(program, vs); GLES20.glAttachShader(program, fs)
        GLES20.glLinkProgram(program)
        aPos = GLES20.glGetAttribLocation(program, "aPosition")
        uMvp = GLES20.glGetUniformLocation(program, "uMVP")
        uColor = GLES20.glGetUniformLocation(program, "uColor")
        Matrix.setLookAtM(view, 0, 0f, 5.5f, 10.5f, 0f, 0f, -1f, 0f, 1f, 0f)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        Matrix.perspectiveM(projection, 0, 58f, width.toFloat()/height.coerceAtLeast(1), 0.1f, 80f)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        GLES20.glUseProgram(program)
        val now = System.nanoTime()
        val dt = ((now-last)/1_000_000_000f).coerceIn(0f,0.05f)
        last = now
        if (running && !garage) update(dt)
        drawBox(0f,-1.7f,-16f, 40f,0.15f,45f, floatArrayOf(0.12f,0.48f,0.23f,1f))
        drawBox(0f,-0.65f,-15f, 8.2f,0.12f,42f, floatArrayOf(0.20f,0.21f,0.25f,1f))
        // road shoulders
        drawBox(-4.2f,-0.55f,-15f,0.18f,0.16f,42f,floatArrayOf(0.95f,0.92f,0.78f,1f))
        drawBox(4.2f,-0.55f,-15f,0.18f,0.16f,42f,floatArrayOf(0.95f,0.92f,0.78f,1f))
        // dashed lane markers
        for (i in 0..13) {
            val z = -38f + i*3.4f + roadOffset
            drawBox(-1.37f,-0.53f,z,0.07f,0.035f,1.45f,floatArrayOf(1f,0.86f,0.25f,1f))
            drawBox(1.37f,-0.53f,z,0.07f,0.035f,1.45f,floatArrayOf(1f,0.86f,0.25f,1f))
        }
        // simple low-poly scenery
        for (i in 0..7) {
            val z = -38f + i*6.0f + roadOffset*1.6f
            drawBox(-6.1f,-0.45f,z,0.9f,0.8f,0.9f,floatArrayOf(0.10f,0.42f,0.22f,1f))
            drawBox(6.1f,-0.45f,z-2f,0.9f,0.8f,0.9f,floatArrayOf(0.10f,0.42f,0.22f,1f))
        }
        rivals.forEach { drawCar(laneX(it.lane), -0.12f, it.z, it.color, 0.82f) }
        pickups.forEach {
            drawBox(laneX(it.lane),0.05f,it.z,0.24f,0.24f,0.24f,floatArrayOf(1f,0.78f,0.05f,1f))
        }
        val playerColor = colors[carType.coerceIn(0,3)]
        drawCar(laneX(lane), -0.12f, 2.2f, playerColor, 1f)
        if (garage) {
            // display vehicle on a showroom plinth
            drawBox(0f,-0.85f,0f,5f,0.25f,5f,floatArrayOf(0.12f,0.16f,0.24f,1f))
            drawCar(0f,-0.12f,-1.1f,playerColor,1.45f)
        }
    }

    private fun update(dt: Float) {
        roadOffset = (roadOffset + dt*speed*22f) % 3.4f
        score += (dt*12f).toInt()
        speed = (0.12f + score/9000f).coerceAtMost(0.34f)
        spawn++
        if (spawn > (65 - (speed*80).toInt()).coerceAtLeast(35)) {
            spawn = 0
            val blocked = rivals.filter { it.z > -23f }.map { it.lane }
            val lanes = (0..2).filter { it !in blocked }
            if (lanes.isNotEmpty()) rivals.add(Rival(lanes.random(), -39f, arrayOf(
                floatArrayOf(0.88f,0.16f,0.17f,1f),
                floatArrayOf(0.98f,0.48f,0.08f,1f),
                floatArrayOf(0.72f,0.25f,0.8f,1f)
            ).random()))
        }
        coinSpawn++
        if (coinSpawn > 95) { coinSpawn=0; pickups.add(Pickup(Random.nextInt(0,3), -40f)) }
        rivals.forEach { it.z += dt*speed*90f }
        pickups.forEach { it.z += dt*speed*90f }
        // Collision / coin pickup. A hit ends the current run; tap Start Race to restart.
        val hit = rivals.any { it.lane == lane && kotlin.math.abs(it.z-2.2f) < 2.0f }
        if (hit) running = false
        rivals.removeAll { it.z > 7f }
        var earned = 0
        pickups.removeAll {
            val collected = it.lane == lane && kotlin.math.abs(it.z-2.2f) < 1.8f
            if (collected) { score += 100; earned++ }
            collected || it.z > 7f
        }
        if (earned > 0) onCoinsEarned?.invoke(earned)
    }

    private fun drawCar(x: Float, y: Float, z: Float, color: FloatArray, scale: Float) {
        drawBox(x,y,z,0.88f*scale,0.42f*scale,1.65f*scale,color)
        drawBox(x,y+0.34f*scale,z-0.12f*scale,0.56f*scale,0.32f*scale,0.72f*scale,floatArrayOf(0.20f,0.78f,0.9f,1f))
        // wheels
        for (side in listOf(-1f,1f)) for (front in listOf(-1f,1f)) {
            drawBox(x+side*0.49f*scale,y-0.12f*scale,z+front*0.52f*scale,0.18f*scale,0.30f*scale,0.42f*scale,floatArrayOf(0.04f,0.05f,0.07f,1f))
        }
        drawBox(x-0.25f*scale,y+0.06f*scale,z+0.82f*scale,0.18f*scale,0.10f*scale,0.08f*scale,floatArrayOf(1f,0.95f,0.55f,1f))
        drawBox(x+0.25f*scale,y+0.06f*scale,z+0.82f*scale,0.18f*scale,0.10f*scale,0.08f*scale,floatArrayOf(1f,0.95f,0.55f,1f))
    }

    private fun laneX(l: Int) = (l-1)*2.72f

    private fun drawBox(x: Float,y: Float,z: Float,sx: Float,sy: Float,sz: Float,color: FloatArray) {
        val vertices = floatArrayOf(
            -1f,-1f, 1f,  1f,-1f, 1f,  1f, 1f, 1f,  -1f,1f,1f,
            -1f,-1f,-1f, 1f,-1f,-1f, 1f,1f,-1f, -1f,1f,-1f
        )
        val indices = shortArrayOf(
            0,1,2,0,2,3, 5,4,7,5,7,6,
            4,0,3,4,3,7, 1,5,6,1,6,2,
            3,2,6,3,6,7, 4,5,1,4,1,0
        )
        val data = ByteBuffer.allocateDirect(vertices.size*4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        data.put(vertices).position(0)
        val idx = ByteBuffer.allocateDirect(indices.size*2).order(ByteOrder.nativeOrder()).asShortBuffer()
        idx.put(indices).position(0)
        Matrix.setIdentityM(model,0)
        Matrix.translateM(model,0,x,y,z)
        Matrix.scaleM(model,0,sx,sy,sz)
        Matrix.multiplyMM(mvp,0,view,0,model,0)
        Matrix.multiplyMM(mvp,0,projection,0,mvp,0)
        GLES20.glUniformMatrix4fv(uMvp,1,false,mvp,0)
        GLES20.glUniform4fv(uColor,1,color,0)
        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glVertexAttribPointer(aPos,3,GLES20.GL_FLOAT,false,12,data)
        GLES20.glDrawElements(GLES20.GL_TRIANGLES,indices.size,GLES20.GL_UNSIGNED_SHORT,idx)
        GLES20.glDisableVertexAttribArray(aPos)
    }

    private fun compile(type: Int, source: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader,source)
        GLES20.glCompileShader(shader)
        return shader
    }

    fun steer(direction: Int) { lane = (lane + direction).coerceIn(0,2) }
    fun startRace() { lane=1; score=0; spawn=0; coinSpawn=0; speed=0.12f; rivals.clear(); pickups.clear(); running=true; garage=false }
    fun showGarage(show: Boolean) { garage=show; if (show) running=false }
    fun setCar(index: Int) { carType=index.coerceIn(0,3) }
}
