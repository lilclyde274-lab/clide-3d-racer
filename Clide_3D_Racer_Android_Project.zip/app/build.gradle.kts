plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.clide.racer3d"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.clide.racer3d"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
