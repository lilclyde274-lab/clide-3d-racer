# Clide 3D Racer — Native Android Project

This is a native Android application project written in Kotlin using OpenGL ES 2.0. It is not a website and does not use WebView.

## Features
- Landscape 3D-perspective highway racer rendered with OpenGL ES
- Low-poly 3D cars, road, lane markers, scenery and coin pickups
- On-screen left/right steering
- Garage with four car models and coin prices
- Owner label at the top-left: OWNER: CLIDE TABASON
- Coins and owned cars saved locally
- Offline gameplay; no network permission required

## Build requirements
- Android Studio
- JDK 17
- Android SDK Platform 35
- Android Gradle Plugin 8.7.3 / Kotlin 2.0.21

Open the project folder in Android Studio and build an APK for device testing. For Play Store, create a signed Android App Bundle (.aab), complete the Play Console listing, privacy/data-safety details and testing requirements, then submit for review.

Important: this ZIP is source code, not an installable APK or a Play Store-approved release. The project needs to be built, tested on a real device, and reviewed before publication.
